/* .js files add interaction to your website */

//document.getElementById(Contact).addEventListener("click", webLink);
 function webLink(){
//onclick="https://jaynesri.wixsite.com/lths2022/contact-8";
// }

